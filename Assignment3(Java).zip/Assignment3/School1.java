package growskill.Assignment3;

import java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy;

class Schools1{
	String name;
	String address;
	int strength;

	public Schools1(String name,String address) {
       this.name=name;
       this.address=address;
       
	}
	public Schools1(String name,String address,int strength) {
       this.name=name;
       this.address=address;
       this.strength=strength;
	}
	void display() {
		System.out.println("name of school: "+name+", address: "+address+", strength: "+strength);
	}
}
public class School1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Schools1 s1=new Schools1("sandhya","svt street");
		Schools1 s2=new Schools1("sandhya","svt street",500);
       s1.display();
       s2.display();
	}

}
