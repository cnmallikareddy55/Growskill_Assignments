package growskill.Assignment3;
class Shapes{

	int length=4;
	public int areaOfSquare(int s) {
		int area=s*s;
		return area;
	}
	
	int breadth;
	public void areaOfRectangle(int l,int b) {
		int rectRes=l*b; 
		System.out.println("Area of rectangle is: "+rectRes);
	}
	
	int radius=4;
	public void areaOfCircle() {
		double circleRes=3.14*(radius*radius);
		System.out.println("area of circle is  : "+circleRes);
	}
	
	
}
public class Shape {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shapes s=new Shapes();
		int resultSquare=s.areaOfSquare(s.length);
		System.out.println("Area of square is: "+resultSquare);
		s.breadth=3;
		s.areaOfRectangle(2,s.breadth);
		
		s.areaOfCircle();
		
		
		

	}

}
