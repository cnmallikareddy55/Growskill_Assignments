package growskill.Assignment3;

public class SimpleInterestAndAmount {

	public static void main(String[] args) {
		double p=50000;
		double t=6;
		double r=4;
		
		double si=(p*t*r)/100;
		double amount =p+si;
		System.out.println("simple interest is:"+si);
		System.out.println("total Amount:"+amount);
		
		

	}

}
