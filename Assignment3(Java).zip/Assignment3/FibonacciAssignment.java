package growskill.Assignment3;

public class FibonacciAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=0;
		int num2=1;
		int number=5;
		for(int i=0;i<=number;i++) { 
			int num3=num1+num2; 
			System.out.print(num3+",");
			
			num1=num2;
			num2=num3;
			
		}

	}

}
