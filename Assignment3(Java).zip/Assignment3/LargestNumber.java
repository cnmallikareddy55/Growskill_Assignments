package growskill.Assignment3;

public class LargestNumber {

	public static void main(String[] args) {
       int a=1, b=8,c=9,d=88,e=44;
       if(a>b && a>c && a>d && a>e) {
    	   System.out.println("largest number is:"+a);
       }
       else if(b>a && b>c && b>d && b>e) {
    	   System.out.println("largest number is:"+b);
       }
       else if(c>a && c>b && c>d && c>e) {
    	   System.out.println("largest number is:"+c);
       }
       else if(d>a && d>b && d>c && d>e) {
    	   System.out.println("largest number is:"+d);
       }
       else {
    	   System.out.println("largest number is:"+e);
       }
       // another approch using array
       int arr[]= {1,2,4,700,8};
       int largest=arr[0];
       for(int i=1;i<arr.length;i++) {
    	   if(arr[i]>largest) {
    		   largest=arr[i];
    	   }
       }
       System.out.println("largest number in array is:"+largest);
       
	}

}
