package growskill.Assignment3;

public class SumOfEvenNumbers {

	public static void main(String[] args) {
		int num1=1;
		int num2=20;
		int sum=0;
		for(int i=num1;i<=num2;i++) {
			if(i%2==0) {
				sum=sum+i;
			}
		}
      System.out.println("sum of evn numbers between 1 and 20 is:"+sum);
	}

}
