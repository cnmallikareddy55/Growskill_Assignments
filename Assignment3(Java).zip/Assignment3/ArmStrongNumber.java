package growskill.Assignment3;

import java.util.Scanner;

public class ArmStrongNumber {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int input=sc.nextInt();
          int org=input;
          int  sum=0;
          String s=String.valueOf(input);
          int len=s.length();
          
          while(input>0) {
        	  int power=1;
        	  int  digit=input%10; //153%10=3, 15%10=5 1%10=1
        	  for(int i=1;i<=len;i++) {
        		  power=power*digit;//27,125,1
        	  }
        
        	 sum=sum+power;
        	 input=input/10;//153/10=15, 15/10=1, 1/10=0
          }
          if(org==sum) {
        	  System.out.println("givenn input number is Armstrong");
          }else {
        	  System.out.println("given number is not armstrong");
          }
	}

	//Armstrong number  is a number that is equal to the sum 
	 //of its own digits each raised to the power of the number of digits.

}
