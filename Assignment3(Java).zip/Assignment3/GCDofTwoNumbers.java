package growskill.Assignment3;

public class GCDofTwoNumbers {

	public static void main(String[] args) {
	
		int num1=10;
		int num2=40;
		int gcd=1;
		for(int i=1;i<=num1 && i<=num2;i++) {
			if(num1%i==0 && num2%i==0) {// 10%1=0, 33%1=0; || 10%2=0, 40%2=0; || 10%3=!0, 40%3=!0; || 10%4=!0, 40%4=0; || 10%5=0, 40%5=0;
				gcd=i; //10%6=!0, 40%6=!0; || 10%7=!0, 40%7=!0; ||10%8=!0, 40%8=!0; ||10%9=!0, 40%9=!0; ||10%10=0, 40%10=0;
			} // loop stops when i exceeds the smallest of the two numbers because,gcd cant be greater  than smaller number
		}// largest number that divides both of the given numbers without leaving a remainder.
		System.out.println("GCD of two numbers is: "+gcd);

	}

}
