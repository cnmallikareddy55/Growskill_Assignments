package growskill.Assignment3;
class Schools{
	String name="Ravindra Bharathi";
	Schools(){
		System.out.println("shool name is : "+name);
	}
	void display() {
		System.out.println("This School is based out of Kolkata");
	}
	
}
public class School {

	public static void main(String[] args) {
		Schools s1=new Schools();
		s1.display();
		
	}

}
