package growskill.Assignment3;

public class SumOfOddNummbers {

	public static void main(String[] args) {
       int num1=12;
       int num2=20;
       int sum=0;
       for(int i=num1;i<=num2;i++) {
    	   if(i%2==1) {
    		   sum=sum+i;
    	   }
       }
       System.out.println("sum of Odd Numbers from 12 to 20 is:"+sum);
	}

}
