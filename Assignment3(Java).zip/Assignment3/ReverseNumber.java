package growskill.Assignment3;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter input number: ");
		int input=sc.nextInt();
		 int originalNumber=input; 
		int rev=0;
		while(input!=0) {
			int rem=input%10;
			rev=rev*10+rem;
			input=input/10;
		}
		System.out.println("reverse of given number is: "+rev);
       if(rev==originalNumber) {
    	   System.out.println("given number is palindrome");
       }
	}

}
