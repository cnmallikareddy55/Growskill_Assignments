package growskill.Assignment3;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the input number:");
		int inp=sc.nextInt();
		boolean isPrime=true;
		if(inp<=1) {
			isPrime=false;
		}
		else {
		for(int i=2;i<inp;i++) {
			
				if(inp%i==0) {
					isPrime=false;
				}
			}
		}
		if(isPrime) {
			System.out.println("given number is prime number");
		}else {
			System.out.println("not a prime number");
		}
		
		//second approch
		Scanner sc1=new Scanner(System.in);
		System.out.println("enter number:");
		int num2=sc1.nextInt();
		int count=0;
		for(int i=1;i<=num2;i++) {
			if(num2%i==0) {
			 count=count+1;	
			}
		}
		if(count==2) {
			System.out.println("given num2 is prime");
		}else {
			System.out.println("not prime number");
		}

	}

}
