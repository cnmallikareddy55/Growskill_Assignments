package growskill.Assignment3;
class Cars{
	String brand;
	public Cars(String brand) {
		this.brand=brand;
	}
	public String getBrand() {
		return brand;
	}
}
public class Car {

	public static void main(String[] args) {
		Cars c=new Cars("Ford");
       
		String brandName=c.getBrand();
		System.out.println(brandName);
	}

}
